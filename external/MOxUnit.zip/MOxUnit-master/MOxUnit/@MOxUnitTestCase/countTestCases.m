function c=countTestCases(obj)
    c=1;
