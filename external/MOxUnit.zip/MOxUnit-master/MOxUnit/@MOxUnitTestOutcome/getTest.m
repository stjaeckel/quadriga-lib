function test_=getTest(obj)
% return test object
%
% test_=getTest(obj)
%
% Input:
%   obj
    test_=obj.test;

