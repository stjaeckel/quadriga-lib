#include "quadriga_lib.hpp"
#include <iostream>

int main()
{
    std::cout << quadriga_lib::quadriga_lib_version() << std::endl;
}